<?php
// config/twilio.php - fill with your Twilio credentials
return [
    'sid' => '',
    'token' => '',
    'from' => ''
];
?>