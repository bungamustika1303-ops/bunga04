// main JS (empty for now) - add OTP countdown or UI helpers here
