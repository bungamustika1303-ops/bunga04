<?php
require_once '../config/functions.php'; require_role('admin');
// placeholder for payments management
?>
<!doctype html><html><head><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head><body>
<div class="container mt-4"><h4>Manajemen Pembayaran (placeholder)</h4></div>
</body></html>