<?php require_once '../config/functions.php'; require_role('admin'); ?>
<!doctype html>
<html><head><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head><body>
<div class="container mt-4"><h4>Pengaturan Sistem (placeholder)</h4></div></body></html>